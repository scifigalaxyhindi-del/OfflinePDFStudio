plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.offlinepdfstudio"; compileSdk=35
 defaultConfig { applicationId="com.offlinepdfstudio"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" } }
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("com.tom-roush:pdfbox-android:2.0.27.0") }