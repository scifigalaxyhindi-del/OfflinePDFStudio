package com.offlinepdfstudio

import android.app.*; import android.os.*; import android.content.*; import android.net.Uri; import android.graphics.Color
import android.view.*; import android.widget.*; import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument; import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import java.io.File; import java.io.FileOutputStream

class MainActivity:AppCompatActivity(){
 private lateinit var w:EditText; private lateinit var h:EditText; private lateinit var unit:Spinner; private lateinit var status:TextView
 private var uri:Uri?=null
 override fun onCreate(b:Bundle?){super.onCreate(b);PDFBoxResourceLoader.init(applicationContext);ui()}
 private fun ui(){
  val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,28,28,28)}
  r.addView(TextView(this).apply{text="Offline PDF Studio";textSize=28f})
  r.addView(TextView(this).apply{text="PDF Reader • Resize • Export";textSize=15f})
  val open=Button(this).apply{text="OPEN PDF"}; val info=Button(this).apply{text="PDF INFO / PAGE COUNT"}
  r.addView(open);r.addView(info);r.addView(TextView(this).apply{text="Output page size";textSize=18f})
  val presets=arrayOf("5.5 × 8.5 inch (Default)","A4","A5","Letter","Legal","Custom")
  val p=Spinner(this);p.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,presets);r.addView(p)
  val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  w=EditText(this).apply{hint="Width";inputType=2 or 8192};h=EditText(this).apply{hint="Height";inputType=2 or 8192}
  unit=Spinner(this);unit.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("mm","inch","pt"))
  row.addView(w,LinearLayout.LayoutParams(0,-2,1f));row.addView(h,LinearLayout.LayoutParams(0,-2,1f));row.addView(unit,LinearLayout.LayoutParams(0,-2,.8f));r.addView(row)
  val ex=Button(this).apply{text="RESIZE / EXPORT PDF"};r.addView(ex)
  status=TextView(this).apply{text="Ready — offline.";textSize=14f};r.addView(status);setContentView(r)
  p.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(x:AdapterView<*>?){}
   override fun onItemSelected(x:AdapterView<*>?,v:View?,pos:Int,id:Long){when(pos){0->size("139.7","215.9",0);1->size("210","297",0);2->size("148","210",0);3->size("8.5","11",1);4->size("8.5","14",1)};w.isEnabled=pos==5;h.isEnabled=pos==5;unit.isEnabled=pos==5}}
  open.setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/pdf";addCategory(Intent.CATEGORY_OPENABLE)},100)}
  info.setOnClickListener{info()};ex.setOnClickListener{export()};p.setSelection(0)
 }
 private fun size(a:String,b:String,u:Int){w.setText(a);h.setText(b);unit.setSelection(u)}
 override fun onActivityResult(q:Int,c:Int,d:Intent?){super.onActivityResult(q,c,d);if(q==100&&c==RESULT_OK){uri=d?.data;status.text="Selected PDF:
$uri"}}
 private fun pt(v:Double)=when(unit.selectedItem.toString()){"inch"->v*72;"pt"->v;else->v*72/25.4}
 private fun info(){val u=uri?:return toast("पहले PDF खोलें");try{contentResolver.openInputStream(u).use{doc=PDDocument.load(it);AlertDialog.Builder(this).setTitle("PDF Info").setMessage("Pages: ${doc.numberOfPages}\nEncrypted: ${doc.isEncrypted}").setPositiveButton("OK",null).show();doc.close()}}catch(e:Exception){toast("PDF नहीं पढ़ा गया")}}
 private fun export(){val u=uri?:return toast("पहले PDF खोलें");val ww=pt(w.text.toString().toDoubleOrNull()?:0.0).toFloat();val hh=pt(h.text.toString().toDoubleOrNull()?:0.0).toFloat();if(ww<=0||hh<=0)return toast("Valid size दें")
  try{contentResolver.openInputStream(u).use{doc=PDDocument.load(it);for(page in doc.pages){page.mediaBox=PDRectangle(ww,hh);page.cropBox=PDRectangle(ww,hh)};val f=File(getExternalFilesDir(null),"PDF_${System.currentTimeMillis()}.pdf");FileOutputStream(f).use{doc.save(it)};doc.close();status.text="Exported:\n$f\nOriginal content was not rasterized.";toast("PDF तैयार है")}}catch(e:Exception){toast("Export error: ${e.message}")}}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}